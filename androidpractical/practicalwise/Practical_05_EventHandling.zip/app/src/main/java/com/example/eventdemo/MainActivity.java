package com.example.eventdemo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        Button click = findViewById(R.id.btnClick);
        Button longClick = findViewById(R.id.btnLong);

        click.setOnClickListener(v ->
                Toast.makeText(this, "Button Clicked", Toast.LENGTH_SHORT).show());

        longClick.setOnLongClickListener(v -> {
            Toast.makeText(this, "Long Pressed", Toast.LENGTH_SHORT).show();
            return true;
        });
    }
}
