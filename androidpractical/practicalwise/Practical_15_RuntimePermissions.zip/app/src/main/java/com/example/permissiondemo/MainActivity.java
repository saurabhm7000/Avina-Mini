package com.example.permissiondemo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    int CODE = 100;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        Button btn = findViewById(R.id.btnPermission);

        btn.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Already Granted",
                        Toast.LENGTH_SHORT).show();
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CAMERA}, CODE);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int r, @NonNull String[] p,
                                           @NonNull int[] g) {
        super.onRequestPermissionsResult(r, p, g);

        if (r == CODE && g.length > 0 &&
                g[0] == PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Permission Granted",
                    Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "Permission Denied",
                    Toast.LENGTH_SHORT).show();
    }
}
