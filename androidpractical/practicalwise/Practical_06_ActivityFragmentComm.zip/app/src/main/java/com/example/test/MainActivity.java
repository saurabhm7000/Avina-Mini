package com.example.test;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
        implements MyFragment.Listener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnSend).setOnClickListener(v -> {
            MyFragment fragment = new MyFragment();
            Bundle bundle = new Bundle();
            bundle.putString("msg", "Hello Fragment");
            fragment.setArguments(bundle);

            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.frame, fragment)
                    .commit();
        });
    }

    @Override
    public void sendData(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
