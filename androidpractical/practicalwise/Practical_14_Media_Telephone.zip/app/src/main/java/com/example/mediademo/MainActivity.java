package com.example.mediademo;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    MediaPlayer mp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        Button play = findViewById(R.id.play);
        Button call = findViewById(R.id.call);

        // Media API: plays res/raw/song (song.wav is included; any .mp3 named "song" also works)
        play.setOnClickListener(v -> {
            if (mp != null) mp.release();
            mp = MediaPlayer.create(this, R.raw.song);
            mp.setOnCompletionListener(m -> {
                m.release();
                mp = null;
            });
            mp.start();
            Toast.makeText(this, "Playing Audio", Toast.LENGTH_SHORT).show();
        });

        // Telephone API: opens the dialer (no CALL_PHONE permission needed)
        call.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_DIAL);
            i.setData(Uri.parse("tel:9876543210"));
            startActivity(i);
        });
    }

    @Override
    protected void onDestroy() {
        if (mp != null) {
            mp.release();
            mp = null;
        }
        super.onDestroy();
    }
}
