package com.example.broadcastdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class AeroplaneMode extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        boolean state = intent.getBooleanExtra("state", false);

        if (state)
            Toast.makeText(context, "Airplane Mode Enabled",
                    Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(context, "Airplane Mode Disabled",
                    Toast.LENGTH_SHORT).show();
    }
}
