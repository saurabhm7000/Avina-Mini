package com.example.intentdemo;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        Button explicit = findViewById(R.id.btnExplicit);
        Button implicit = findViewById(R.id.btnImplicit);

        // Explicit intent: names the exact Activity
        explicit.setOnClickListener(v ->
                startActivity(new Intent(this, SecondActivity.class)));

        // Implicit intent: describes an action, Android picks the app
        implicit.setOnClickListener(v ->
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com"))));
    }
}
