package com.example.servicedemo;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    MyBoundService service;
    boolean bound = false;

    ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName n, IBinder b) {
            MyBoundService.LocalBinder binder = (MyBoundService.LocalBinder) b;
            service = binder.getService();
            bound = true;
            Toast.makeText(MainActivity.this,
                    service.getMessage(), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onServiceDisconnected(ComponentName n) {
            bound = false;
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        Button start = findViewById(R.id.btnStart);
        Button stop = findViewById(R.id.btnStop);
        Button bind = findViewById(R.id.btnBound);

        start.setOnClickListener(v ->
                startService(new Intent(this, MyStartedService.class)));

        stop.setOnClickListener(v ->
                stopService(new Intent(this, MyStartedService.class)));

        bind.setOnClickListener(v ->
                bindService(new Intent(this, MyBoundService.class),
                        connection, BIND_AUTO_CREATE));
    }

    @Override
    protected void onDestroy() {
        if (bound) {
            unbindService(connection);
            bound = false;
        }
        super.onDestroy();
    }
}
