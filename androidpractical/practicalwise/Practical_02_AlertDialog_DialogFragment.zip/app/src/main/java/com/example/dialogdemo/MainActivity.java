package com.example.dialogdemo;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        Button alert = findViewById(R.id.btnAlert);
        Button custom = findViewById(R.id.btnCustom);

        alert.setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle("Confirmation")
                        .setMessage("Do you want to continue?")
                        .setPositiveButton("YES", null)
                        .setNegativeButton("NO", null)
                        .show()
        );

        custom.setOnClickListener(v ->
                new CustomDialogFragment()
                        .show(getSupportFragmentManager(), "Dialog")
        );
    }
}
