package com.example.dialogdemo;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

public class CustomDialogFragment extends DialogFragment {

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle b) {

        View v = requireActivity().getLayoutInflater()
                .inflate(R.layout.dialog_custom, null);

        EditText name = v.findViewById(R.id.etName);

        return new AlertDialog.Builder(requireActivity())
                .setTitle("Custom Dialog")
                .setView(v)
                .setPositiveButton("OK", (d, w) ->
                        Toast.makeText(getActivity(),
                                "Hello " + name.getText(),
                                Toast.LENGTH_SHORT).show())
                .setNegativeButton("Cancel", null)
                .create();
    }
}
