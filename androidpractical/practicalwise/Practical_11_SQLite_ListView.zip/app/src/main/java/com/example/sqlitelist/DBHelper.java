package com.example.sqlitelist;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    DBHelper(Context c) {
        super(c, "StudentDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE student(name TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
    }

    void insert(String name) {
        getWritableDatabase().execSQL(
                "INSERT INTO student VALUES(?)",
                new String[]{name});
    }

    ArrayList<String> getNames() {
        ArrayList<String> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM student", null);
        while (c.moveToNext())
            list.add(c.getString(0));
        c.close();
        return list;
    }
}
