package com.example.sqlitelist;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText name;
    ListView list;
    DBHelper db;
    ArrayAdapter<String> adapter;
    ArrayList<String> data;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.name);
        list = findViewById(R.id.list);
        db = new DBHelper(this);

        data = db.getNames();
        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                data);
        list.setAdapter(adapter);

        findViewById(R.id.add).setOnClickListener(v -> {
            String n = name.getText().toString();
            db.insert(n);
            data.add(n);
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Student Added", Toast.LENGTH_SHORT).show();
            name.setText("");
        });
    }
}
