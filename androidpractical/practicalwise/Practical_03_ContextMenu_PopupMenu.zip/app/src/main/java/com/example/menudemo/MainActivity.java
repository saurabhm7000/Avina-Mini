package com.example.menudemo;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        TextView txt = findViewById(R.id.txt);
        Button btn = findViewById(R.id.btn);

        // Contextual menu: long-press on the TextView
        registerForContextMenu(txt);

        // Popup menu: click on the Button
        btn.setOnClickListener(v -> {
            PopupMenu p = new PopupMenu(this, btn);
            p.getMenuInflater().inflate(R.menu.menu_options, p.getMenu());

            p.setOnMenuItemClickListener(item -> {
                Toast.makeText(this, item.getTitle(),
                        Toast.LENGTH_SHORT).show();
                return true;
            });
            p.show();
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo info) {
        super.onCreateContextMenu(menu, v, info);
        getMenuInflater().inflate(R.menu.menu_options, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Toast.makeText(this, item.getTitle(),
                Toast.LENGTH_SHORT).show();
        return true;
    }
}
