package com.example.threadsdemo;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        TextView result = findViewById(R.id.result);

        findViewById(R.id.btn).setOnClickListener(v -> {
            new Thread(() -> {
                try {
                    Thread.sleep(3000);   // background work

                    // Handler posts the result back to the main (UI) thread
                    new Handler(Looper.getMainLooper()).post(() -> {
                        result.setText("Task Completed");
                        Toast.makeText(this, "Completed",
                                Toast.LENGTH_SHORT).show();
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        });
    }
}
