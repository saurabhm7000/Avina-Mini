package com.example.gridviewdemo;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    GridView gridView;

    int[] images = {
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridView);

        CustomAdapter adapter = new CustomAdapter(this, images);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener((parent, view, position, id) ->
                Toast.makeText(this, "Image " + (position + 1) + " Selected",
                        Toast.LENGTH_SHORT).show());
    }
}
