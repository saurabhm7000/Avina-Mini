package com.example.jsondemo;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        TextView result = findViewById(R.id.result);

        findViewById(R.id.btn).setOnClickListener(v ->
                new Thread(() -> {
                    try {
                        URL u = new URL(
                                "https://jsonplaceholder.typicode.com/posts/1");
                        BufferedReader r = new BufferedReader(
                                new InputStreamReader(u.openStream()));
                        StringBuilder s = new StringBuilder();
                        String x;
                        while ((x = r.readLine()) != null) s.append(x);
                        r.close();

                        JSONObject o = new JSONObject(s.toString());
                        String data = "Title: " + o.getString("title")
                                + "\n\nBody: " + o.getString("body");

                        runOnUiThread(() -> {
                            result.setText(data);
                            Toast.makeText(this, "Data Fetched",
                                    Toast.LENGTH_SHORT).show();
                        });
                    } catch (Exception e) {
                        // UI must only be touched on the main thread
                        runOnUiThread(() -> result.setText("Error"));
                    }
                }).start()
        );
    }
}
