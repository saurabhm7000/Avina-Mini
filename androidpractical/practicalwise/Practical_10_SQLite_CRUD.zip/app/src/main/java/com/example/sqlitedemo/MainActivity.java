package com.example.sqlitedemo;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText name, newName;
    TextView result;
    DBHelper db;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.name);
        newName = findViewById(R.id.newName);
        result = findViewById(R.id.result);
        db = new DBHelper(this);

        findViewById(R.id.insert).setOnClickListener(v -> {
            db.insert(name.getText().toString());
            Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.view).setOnClickListener(v ->
                result.setText(db.view()));

        findViewById(R.id.update).setOnClickListener(v -> {
            db.update(name.getText().toString(),
                    newName.getText().toString());
            Toast.makeText(this, "Data Updated", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.delete).setOnClickListener(v -> {
            db.delete(name.getText().toString());
            Toast.makeText(this, "Data Deleted", Toast.LENGTH_SHORT).show();
        });
    }
}
