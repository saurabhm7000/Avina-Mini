package com.example.sqlitedemo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    DBHelper(Context c) {
        super(c, "StudentDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE student(name TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
    }

    // INSERT
    void insert(String name) {
        getWritableDatabase().execSQL(
                "INSERT INTO student VALUES(?)",
                new String[]{name});
    }

    // VIEW
    String view() {
        Cursor c = getReadableDatabase()
                .rawQuery("SELECT * FROM student", null);
        StringBuilder s = new StringBuilder();
        while (c.moveToNext())
            s.append(c.getString(0)).append("\n");
        c.close();
        return s.toString();
    }

    // UPDATE
    void update(String oldName, String newName) {
        getWritableDatabase().execSQL(
                "UPDATE student SET name=? WHERE name=?",
                new String[]{newName, oldName});
    }

    // DELETE
    void delete(String name) {
        getWritableDatabase().execSQL(
                "DELETE FROM student WHERE name=?",
                new String[]{name});
    }
}
