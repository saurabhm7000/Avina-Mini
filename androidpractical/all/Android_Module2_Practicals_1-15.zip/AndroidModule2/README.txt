Android Module 2 - Practicals 1-15 (Java, Android Studio)

Each Practical_XX_* folder is an independent Android Studio project.
Open: Android Studio > File > Open > select ONE practical folder.
Let Gradle sync (needs internet the first time), then press Run.

Config: AGP 8.5.2, Gradle 8.7, compileSdk 34, minSdk 24, Java.
Notes:
 - Practical 8: Android 13+ needs the notification permission; the app asks for it on launch.
 - Practical 12: needs internet on the emulator/device.
 - Practical 14: res/raw/song.wav is a generated melody; replace with your own song (mp3/wav, named 'song').
 - Practical 9: toggle Airplane Mode from the emulator's quick settings to see the Toast.
