package com.example.linearlayoutdemo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText edtName, edtCourse;
    Button btnSave, btnClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtName = findViewById(R.id.edtName);
        edtCourse = findViewById(R.id.edtCourse);
        btnSave = findViewById(R.id.btnSave);
        btnClear = findViewById(R.id.btnClear);

        btnSave.setOnClickListener(v ->
                Toast.makeText(this, "Details Saved", Toast.LENGTH_SHORT).show());

        btnClear.setOnClickListener(v -> {
            edtName.setText("");
            edtCourse.setText("");
            Toast.makeText(this, "Fields Cleared", Toast.LENGTH_SHORT).show();
        });
    }
}
