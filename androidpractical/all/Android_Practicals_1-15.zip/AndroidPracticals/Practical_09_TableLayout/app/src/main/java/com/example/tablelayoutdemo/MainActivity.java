package com.example.tablelayoutdemo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText edtUsername, edtPassword;
    Button btnLogin, btnClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnClear = findViewById(R.id.btnClear);

        btnLogin.setOnClickListener(v ->
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show());

        btnClear.setOnClickListener(v -> {
            edtUsername.setText("");
            edtPassword.setText("");
            Toast.makeText(this, "Fields Cleared", Toast.LENGTH_SHORT).show();
        });
    }
}
