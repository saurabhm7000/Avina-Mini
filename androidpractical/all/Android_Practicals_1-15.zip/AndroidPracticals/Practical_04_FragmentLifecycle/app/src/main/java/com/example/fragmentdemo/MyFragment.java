package com.example.fragmentdemo;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class MyFragment extends Fragment {

    private static final String TAG = "FragmentLifecycle";

    private void showMessage(String message) {
        if (getContext() != null) {
            Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
        }
        Log.d(TAG, message);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showMessage("onCreate()");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        showMessage("onCreateView()");
        return inflater.inflate(R.layout.fragment_my, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();
        showMessage("onStart()");
    }

    @Override
    public void onResume() {
        super.onResume();
        showMessage("onResume()");
    }

    @Override
    public void onPause() {
        super.onPause();
        showMessage("onPause()");
    }

    @Override
    public void onStop() {
        super.onStop();
        showMessage("onStop()");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        showMessage("onDestroyView()");
    }
}
