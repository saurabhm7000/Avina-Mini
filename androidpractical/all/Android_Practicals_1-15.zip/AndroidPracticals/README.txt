Android Practicals 1-15 (Java, Android Studio)

Each Practical_XX_* folder is an independent Android Studio project.
Open: Android Studio > File > Open > select ONE practical folder.
Let Gradle sync (needs internet the first time), then press Run.

Config: AGP 8.5.2, Gradle 8.7, compileSdk 34, minSdk 24, Java.
Practical 2/12/14 use generated vector drawables as placeholder images
(img, sample_image, image1-4). Replace them with your own PNG/JPG of the
same name in res/drawable (delete the .xml version) if you prefer.
